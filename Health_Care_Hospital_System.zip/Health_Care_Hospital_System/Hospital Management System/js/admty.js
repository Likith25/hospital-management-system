var x = "Basic Administartion"; 
var y = "Super Administartion";

if(document.getElementById("admte").value == x)
{
 document.getElementById("lock").style.display = 'none';
}else{
	document.getElementById("lock").bgColor = "#ffff00";
}