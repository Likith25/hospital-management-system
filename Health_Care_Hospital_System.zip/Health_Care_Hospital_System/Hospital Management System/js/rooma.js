
var x = "NAV";
var y = "AV";

if(document.getElementById("ro1").value == x){
document.getElementById("r1").bgColor = "#ff9999";
document.getElementById("rr1").style.visibility = "show"
}else
{document.getElementById("r1").bgColor = "#00ff00";
document.getElementById("rr1").style.visibility = "hidden"}

if(document.getElementById("ro2").value == x){
document.getElementById("r2").bgColor = "#ff9999";
document.getElementById("rr2").style.visibility = "show"
}else{document.getElementById("r2").bgColor = "#00ff00";
document.getElementById("rr2").style.visibility = "hidden"}

if(document.getElementById("ro3").value == x){
document.getElementById("r3").bgColor = "#ff9999";
document.getElementById("rr3").style.visibility = "show"
}else{document.getElementById("r3").bgColor = "#00ff00";
document.getElementById("rr3").style.visibility = "hidden"}

if(document.getElementById("ro4").value == x){
document.getElementById("r4").bgColor = "#ff9999";
document.getElementById("rr4").style.visibility = "show"
}else{document.getElementById("r4").bgColor = "#00ff00";
document.getElementById("rr4").style.visibility = "hidden"}

if(document.getElementById("ro5").value == x){
document.getElementById("r5").bgColor = "#ff9999";
document.getElementById("rr5").style.visibility = "show"
}else{document.getElementById("r5").bgColor = "#00ff00";
document.getElementById("rr5").style.visibility = "hidden"}

if(document.getElementById("ro6").value == x){
document.getElementById("r6").bgColor = "#ff9999";
document.getElementById("rr6").style.visibility = "show"
}else{document.getElementById("r6").bgColor = "#00ff00";
document.getElementById("rr6").style.visibility = "hidden"}

if(document.getElementById("ro7").value == x){
document.getElementById("r7").bgColor = "#ff9999";
document.getElementById("rr7").style.visibility = "show"
}else{document.getElementById("r7").bgColor = "#00ff00";
document.getElementById("rr7").style.visibility = "hidden"}

if(document.getElementById("ro8").value == x){
document.getElementById("r8").bgColor = "#ff9999";
document.getElementById("rr8").style.visibility = "show"
}else{document.getElementById("r8").bgColor = "#00ff00";
document.getElementById("rr8").style.visibility = "hidden"}

if(document.getElementById("ro9").value == x){
document.getElementById("r9").bgColor = "#ff9999";
document.getElementById("rr9").style.visibility = "show"
}else{document.getElementById("r9").bgColor = "#00ff00";
document.getElementById("rr9").style.visibility = "hidden"}

if(document.getElementById("ro10").value == x){
document.getElementById("r10").bgColor = "#ff9999";
document.getElementById("rr10").style.visibility = "show"
}else{document.getElementById("r10").bgColor = "#00ff00";
document.getElementById("rr10").style.visibility = "hidden"}
