
<link href="css/menu.css" rel="stylesheet" type="text/css" />
<br>
<div class="container-fluid footer">
    <div class="row">
    <br>
        <div class="col-md-10 col-md-push-2">
        <div style="text-align: left;" class="col-md-2"><h5 style="font-size: 17px;" >Patient Info</h5>

        <p><a style="color: #767773" href="#">Patient Registration</a><br>
        <a style="color: #767773" href="#">Patient Information</a><br>
        <a style="color: #767773" href="#">Patient Search</a><br>
        </p>

        </div>
        <div style="text-align: left;" class="col-md-2"><h5 style="font-size: 17px;" >Staff Info</h5>
        <p><a style="color: #767773" href="#">Add Staff Memeber</a><br>
        <a style="color: #767773" href="#">Staff Memeber Details</a><br>
        <a style="color: #767773" href="#">Search Staff Memeber</a><br>
        <a style="color: #767773" href="#">Active Memebers</a><br>
        </p>
        </div>
        <div style="text-align: left;" class="col-md-2"><h5 style="font-size: 17px;" >Patient Invoices</h5>
        <p><a style="color: #767773" href="#">OPD Patient Invoices</a><br>
        <a style="color: #767773" href="#">Admited Patient Invoices</a></p></div>
        <div style="text-align: left;" class="col-md-2"><h5 style="font-size: 17px;" >Room Information</h5>
        <p><a style="color: #767773" href="#">Room Avilability</a></p></div>
        <div style="text-align: left;" class="col-md-2"><h5 style="font-size: 17px;" >Admited Patient Information</h5>
        <p id=""><a style="color: #767773" href="#">Admited Patient Information</a></p></div>
        </div>
        </div>
    </div>
   <div class="container-fluid foot2">
    <div class="row">
        <div style="padding: 10px;" class="col-md-10 col-md-push-2">
Copyright © 2016 Jayendra Matarage. All rights reserved.
        </div>
    </div>
    </div>