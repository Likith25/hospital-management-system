# Hospital-Management-System
"Health Care hospital" Management System is designed for manage details about hospital patient,employee and rooms(10). Designed by using HTML / CSS / JS / JQUERY/ PHP (procedural php) / MYSQL. 

Languages and Framworks HTML CSS JS PHP (procedural php) MYSQL JQUERY BOOTSTRAP

Import Database file from DATABASE and USERMANUAL folder.
User Manual Included
1)Create Account for System to create need to enter Top level Adminstration login details to system.

Top level Adminstration login  details.
Username = Admin
Password = Password

Example Super Admin Login
Username = superAdmin
Password = 123

Example Basic Admin Login
Username = BasicAdmin
Password = 123
